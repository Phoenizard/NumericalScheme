"""Read colored reference curves, retaining the original pixel calibration."""

import json
from pathlib import Path

import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent
pixels = np.asarray(Image.open(HERE / "figure3_reference.png").convert("RGB"))
r, g, b = (pixels[:, :, i].astype(float) for i in range(3))
masks = {
    "sav": (r < 80) & (g > 80) & (b > 120) & (b > 1.1 * g),
    "pb8": (r > 180) & (g > 90) & (g < 210) & (b < 80),
    "pb30": (r > 180) & (g < 100) & (b < 100),
    "gd": (g > 100) & (r < 80) & (g > 1.1 * b),
}
result = {"calibration": {"x_zero": 92, "x_600": 590,
                           "y_0.1": 152, "y_0.01": 277},
          "note": "Pixel estimates, not author numerical records; line/marker uncertainty ~3px."}
for method, mask in masks.items():
    x_pixels, y_pixels = [], []
    for column in range(94, 590):
        indices = np.flatnonzero(mask[85:365, column]) + 85
        if len(indices):
            x_pixels.append(column)
            y_pixels.append(float(np.median(indices)))
    checkpoints = {}
    for step in [50, 100, 200, 300, 400, 500, 600]:
        column = 92 + step * (590 - 92) / 600
        ordinate = np.interp(column, x_pixels, y_pixels)
        checkpoints[str(step)] = 10 ** (-1 - (ordinate - 152) / 125)
    result[method] = checkpoints
(HERE / "reference_points.json").write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
