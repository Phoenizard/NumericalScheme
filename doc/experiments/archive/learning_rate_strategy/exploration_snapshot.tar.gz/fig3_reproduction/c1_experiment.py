"""One nonlinear SAV/ESAV experiment with the unchanged R21 controller."""

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import torch

from accepted_experiment import HERE, ROOT, initialize, load_data, predict, residual_jacobian
import tracking


def controlled_rate(eta, jac, x, V, config):
    """Apply the unchanged R21 damping policy to the method's actual implicit matrix."""
    gauss_newton = jac.T @ jac / len(x)
    pullback = V @ V.T
    missing=gauss_newton-config.get("implicit_factor",1.0)*pullback
    largest=torch.linalg.eigvalsh(missing)[-1].item()
    safety = config.get("damping_safety", 1.0)
    if config.get("retention_safety", False):
        retained = (torch.trace(pullback) / torch.trace(gauss_newton)).item()
        safety += (config.get("maximum_safety", 2.0) - safety) * min(1.0, max(0.0, retained))
    bound = min(100.0, max(1e-6, safety / max(largest, 1e-12)))
    eta = min(eta, bound) if config.get("growth_envelope", False) else bound
    return eta


def accepted_step(theta, x, y, energy, grad, V, rhs, eta, config):
    """Backtrack without mutating parameters or any auxiliary state."""
    backtracks = 0
    while True:
        if V.shape[1]:
            increment = eta * rhs - eta * V @ torch.linalg.solve(
                torch.eye(V.shape[1]) + eta * (V.T @ V), V.T @ (eta * rhs))
        else:
            increment = eta * rhs
        trial = theta + increment
        trial_energy = (predict(trial, x) - y).square().mean() / 2
        if torch.isfinite(trial_energy) and trial_energy <= energy + config["armijo"] * (grad @ increment):
            return trial, trial_energy, increment, eta, backtracks
        if eta <= 1e-6:
            raise FloatingPointError("Armijo failed at minimum rate")
        eta = max(1e-6, eta * 0.5)
        backtracks += 1


def esav_auxiliary(log_r, initial_energy, ratio, grad, increment, trial_energy, relax):
    """Update the existing ESAV auxiliary state after an accepted parameter step."""
    if relax:
        return torch.minimum(trial_energy / (4 * initial_energy), log_r)
    return log_r + ratio * (grad @ increment) / (4 * initial_energy)


def nested_groups(n, count, seed):
    """Use the same largest-group bisection of a NumPy permutation as R21."""
    groups = [torch.tensor(np.random.RandomState(seed).permutation(n))]
    while len(groups) < count:
        index = max(range(len(groups)), key=lambda i: len(groups[i]))
        groups[index:index + 1] = list(groups[index].tensor_split(2))
    return groups


def component_quantities(residual, jac, groups):
    """Return the existing energy partition and its first derivatives."""
    energies = torch.stack([residual[group].square().sum() / (2 * len(residual))
                            for group in groups])
    gradients = torch.stack([jac[group].T @ residual[group] / len(residual)
                             for group in groups], dim=1)
    return energies, gradients


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--method", required=True,
                        choices=["sav", "esav", "relax_esav", "adam", "pb_sav", "pb_esav"])
    parser.add_argument("--components", type=int, choices=[8, 16, 30])
    args = parser.parse_args()
    is_pb = args.method in ["pb_sav", "pb_esav"]
    is_sav = args.method in ["sav", "pb_sav"]
    if is_pb != (args.components is not None):
        parser.error("PB methods require --components; base methods do not accept it")
    count = args.components or 1
    run_key = f"{args.method}_m{count}" if is_pb else args.method
    config_path = HERE / "c1_config.json"
    config = json.loads(config_path.read_text())
    config.update(method=args.method, relax=args.method == "relax_esav", dtype="float64",
                  device="cpu", batch_policy="full_batch", reference_round="r21")
    if is_pb:
        config.update(round="d1_pb_no_relax", components=count)
    folder = HERE / "runs" / config["round"] / run_key
    if folder.exists():
        raise ValueError(f"Refusing to overwrite {folder}")
    x, y = load_data(config)
    theta = initialize(config)
    digest = hashlib.sha256(torch.cat((x, y, theta)).numpy().tobytes()).hexdigest()
    if digest != config["expected_input_sha256"]:
        raise ValueError("Data or initialization differs from the accepted R21 run")
    config.update(input_sha256=digest, data_path=str(HERE / "inputs/r21.pt"))
    groups = nested_groups(len(x), count, config["partition_seed"])
    config["group_indices"] = [group.tolist() for group in groups]
    initial_energy = (predict(theta, x) - y).square().mean() / 2
    initial_components, _ = component_quantities(predict(theta, x) - y,
                                                residual_jacobian(theta, x), groups)
    if args.method == "pb_esav":
        if not torch.isfinite(initial_components).all() or (initial_components <= 0).any():
            raise ValueError("PB-ESAV requires positive finite initial component energies")
        initial_energy = initial_components.sum()
        config["initial_components"] = initial_components.tolist()
    config["initial_energy"] = initial_energy.item()
    config["auxiliary_definition"] = {
        "sav": "q=sqrt(E+C)", "esav": "r=exp(E/(4*E0))",
        "relax_esav": "r=exp(E/(4*E0)); relax total log_r", "adam": "none",
        "pb_sav": "q=sqrt(E+C); one total auxiliary state",
        "pb_esav": "r=exp(E/(4*E0)); r_i=exp(E_i/(4*E_i0)); frozen E0 and E_i0",
    }[args.method]
    if args.method == "adam":
        config["effective_learning_rate_policy"] = {"strategy": "fixed", "lr": config["adam_lr"]}
    else:
        keys = ["controller", "initial_lr", "growth", "damping_safety", "implicit_factor",
                "retention_safety", "maximum_safety", "growth_envelope", "armijo"]
        config["effective_learning_rate_policy"] = {key: config[key] for key in keys}
    sdk = tracking._sdk(ROOT)
    remote = sdk.init(entity="pheonizard-university-of-nottingham", project="NumericalScheme",
                      name=f"nonlinear_{config['round']}_{run_key}", mode="online", config=config,
                      settings=sdk.Settings(init_timeout=30, finish_timeout=60,
                                            disable_git=True, save_code=False, x_disable_meta=True))
    if remote is None or remote.offline or remote.disabled:
        raise RuntimeError("Online W&B recording required before training")
    folder.mkdir(parents=True)
    source = sdk.Artifact(f"source-{remote.id}", type="experiment-source")
    for path in [Path(__file__), config_path, HERE / "accepted_experiment.py",
                 HERE / "c1_validate.py", ROOT / "optimizer/esav.py",
                 HERE / "pb_validate.py", ROOT / "optimizer/pb_esav.py",
                 ROOT / "optimizer/pb_sav.py", ROOT / "doc/design/esav.md", ROOT / "tracking.py"]:
        source.add_file(str(path), name=str(path.relative_to(ROOT)))
    remote.log_artifact(source)
    remote.define_metric("iteration")
    remote.define_metric("*", step_metric="iteration")
    q = (initial_energy + config["shift"]).sqrt()
    log_r = torch.tensor(0.25)
    log_r_i = torch.full((count,), 0.25)
    eta = config["initial_lr"]
    accepted_lr, backtracks, armijo_ratio = 0.0, 0, 0.0
    test_x = torch.linspace(0, 1, 1001)
    rows, best_test, status = [], float("inf"), "completed"
    adam_theta = theta.clone().requires_grad_(True)
    adam = torch.optim.Adam([adam_theta], lr=config["adam_lr"],
                            betas=tuple(config["adam_betas"]), eps=config["adam_eps"],
                            weight_decay=config["adam_weight_decay"], amsgrad=False
                            ) if args.method == "adam" else None
    try:
        for iteration in range(config["steps"] + 1):
            residual = predict(theta, x) - y
            jac = residual_jacobian(theta, x)
            energy = residual.square().mean() / 2
            grad = jac.T @ residual / len(x)
            if is_pb:
                energies, gradients = component_quantities(residual, jac, groups)
                if args.method == "pb_esav":
                    energy = energies.sum()
                    grad = gradients.sum(dim=1)
            test = (predict(theta, test_x) - torch.sin(2 * torch.pi * test_x)).square().mean().item()
            best_test = min(best_test, test)
            row = dict(iteration=iteration, objective=energy.item(), gradient_norm=grad.norm().item(),
                       test_mse=test, lr=accepted_lr, backtracks=backtracks, armijo_ratio=armijo_ratio)
            if is_sav:
                Q = (energy + config["shift"]).sqrt()
                ratio = q / Q
                row.update(q=q.item(), q_current=Q.item(), aux_ratio=ratio.item(),
                           auxiliary_energy=q.square().item(),
                           auxiliary_consistency=(q.square() - Q.square()).item())
            elif adam is None:
                ratio = (log_r - energy / (4 * initial_energy)).exp()
                row.update(log_r=log_r.item(), aux_ratio=ratio.item(),
                           auxiliary_energy=(4 * initial_energy * log_r).item(),
                           auxiliary_consistency=(4 * initial_energy * log_r - energy).item())
            if is_pb:
                for component in range(count):
                    row[f"energy_{component}"] = energies[component].item()
            if args.method == "pb_esav":
                component_ratios = (log_r_i - energies / (4 * initial_components)).exp()
                row["component_ratio_floor_count"] = int((component_ratios == 0).sum())
                component_ratios.masked_fill_(component_ratios == 0, torch.finfo(energy.dtype).tiny)
                for component in range(count):
                    row[f"log_r_{component}"] = log_r_i[component].item()
                    row[f"aux_ratio_{component}"] = component_ratios[component].item()
            rows.append(row)
            remote.log(row, step=iteration)
            if not all(math.isfinite(value) for value in row.values()):
                raise FloatingPointError(f"Nonfinite state at accepted iteration {iteration}: {row}")
            if iteration == config["steps"]:
                break
            if adam is not None:
                adam.zero_grad()
                loss = (predict(adam_theta, x) - y).square().mean() / 2
                loss.backward()
                adam.step()
                theta = adam_theta.detach().clone()
                accepted_lr = config["adam_lr"]
                continue
            if ratio <= 0:
                raise FloatingPointError(f"Nonpositive auxiliary ratio at iteration {iteration}")
            if is_sav:
                if not is_pb:
                    energies, gradients = component_quantities(residual, jac, groups)
                V = gradients / torch.sqrt(2 * (energies + config["shift"] / count))
            elif args.method == "pb_esav":
                V = gradients * (component_ratios / (4 * initial_components).sqrt())
            else:
                V = torch.empty((len(theta), 0))
            rhs = -ratio * grad
            eta = controlled_rate(eta, jac, x, V, config)
            trial, trial_energy, increment, accepted_lr, backtracks = accepted_step(
                theta, x, y, energy, grad, V, rhs, eta, config)
            armijo_ratio = ((energy - trial_energy) / (-grad @ increment)).item()
            with torch.no_grad():
                if is_sav:
                    q = q + grad @ increment / (2 * Q)
                else:
                    log_r = esav_auxiliary(log_r, initial_energy, ratio, grad, increment,
                                           trial_energy, config["relax"])
                    if args.method == "pb_esav":
                        log_r_i = log_r_i + component_ratios * (gradients.T @ increment) / (4 * initial_components)
                theta = trial.detach()
            eta = min(100.0, accepted_lr * config["growth"])
    except BaseException as error:
        status = "failed"
        (folder / "failure.txt").write_text(repr(error))
        raise
    finally:
        if rows:
            with (folder / "history.csv").open("w", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
                writer.writeheader()
                writer.writerows(rows)
        summary = dict(status=status, best_test_mse=best_test, **(rows[-1] if rows else {}),
                       url=remote.url)
        (folder / "config.json").write_text(json.dumps(config, indent=2))
        (folder / "summary.json").write_text(json.dumps(summary, indent=2))
        remote.summary.update(summary)
        records = sdk.Artifact(f"records-{remote.id}", type="experiment-record")
        for path in folder.glob("*.*"):
            records.add_file(str(path), name=path.name)
        remote.log_artifact(records)
        remote.finish(exit_code=0 if status == "completed" else 1)
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
