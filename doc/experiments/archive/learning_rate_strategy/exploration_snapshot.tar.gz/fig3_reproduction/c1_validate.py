"""Check unchanged controller, inputs, ESAV steps and trial rollback without training."""

import ast
import hashlib
import inspect
import json

import torch

import accepted_experiment as reference
from c1_experiment import HERE, accepted_step, controlled_rate, esav_auxiliary
from optimizer import esav


config = json.loads((HERE / "c1_config.json").read_text())
baseline = json.loads((HERE / "accepted_config.json").read_text())
keys = ["controller", "initial_lr", "growth", "damping_safety", "implicit_factor",
        "retention_safety", "maximum_safety", "growth_envelope", "armijo"]
assert all(config[key] == baseline[key] for key in keys)
main = ast.parse(inspect.getsource(reference.main))
old_block = next(node for node in ast.walk(main) if isinstance(node, ast.If)
                 and ast.unparse(node.test) == "config.get('controller') == 'curvature_gap'")
new_function = ast.parse(inspect.getsource(controlled_rate)).body[0]
assert [ast.dump(node, include_attributes=False) for node in old_block.body] == [
    ast.dump(node, include_attributes=False) for node in new_function.body[1:-1]]
x, y = reference.load_data(config)
theta = reference.initialize(config)
assert hashlib.sha256(torch.cat((x, y, theta)).numpy().tobytes()).hexdigest() == config["expected_input_sha256"]
groups = [torch.arange(len(x))]
reference.verify(theta, x, y, groups)
energy = (reference.predict(theta, x) - y).square().mean() / 2
jac = reference.residual_jacobian(theta, x)
grad = jac.T @ (reference.predict(theta, x) - y) / len(x)
checks = 0
for relax in [False, True]:
    for offset in [0.0, -0.02]:
        for rate in [0.1, 0.3]:
            parameter = theta.clone().requires_grad_(True)
            loss_fn = lambda: (reference.predict(parameter, x) - y).square().mean() / 2
            state = esav.initialize(loss_fn())
            state["log_r"] += offset
            old_log = state["log_r"].clone()
            ratio = (old_log - energy / (4 * energy)).exp()
            increment = -rate * ratio * grad
            trial_energy = (reference.predict(theta + increment, x) - y).square().mean() / 2
            expected_log = esav_auxiliary(old_log, energy, ratio, grad, increment, trial_energy, relax)
            new_state = esav.step([parameter], loss_fn, state, rate, relax=relax)
            torch.testing.assert_close(parameter.detach(), theta + increment, rtol=1e-12, atol=1e-12)
            torch.testing.assert_close(new_state["log_r"], expected_log, rtol=1e-12, atol=1e-12)
            torch.testing.assert_close(state["log_r"], old_log, rtol=0, atol=0)
            checks += 1
old_theta = theta.clone()
trial = accepted_step(theta, x, y, energy, grad, torch.empty((151, 0)), -grad, 100.0, config)
assert trial[-1] > 0
torch.testing.assert_close(theta, old_theta, rtol=0, atol=0)
result = {"status": "passed", "training_performed": False, "controller_ast_identical_to_r21": True,
          "controller_parameters_identical_to_r21": True, "inputs_identical_to_r21": True,
          "esav_single_step_checks": checks, "rejected_trials_preserve_parameters": True,
          "auxiliary_state_updated_only_after_acceptance": True}
(HERE / "c1_validation.json").write_text(json.dumps(result, indent=2))
print(json.dumps(result))
