"""Validate PB grouping, original optimizer updates and dissipation before training."""

import hashlib
import json

import torch

from accepted_experiment import HERE, initialize, load_data, predict, residual_jacobian
from c1_experiment import accepted_step, component_quantities, esav_auxiliary, nested_groups
from optimizer import pb_esav, pb_sav


config = json.loads((HERE / "c1_config.json").read_text())
x, y = load_data(config)
theta = initialize(config)
assert hashlib.sha256(torch.cat((x, y, theta)).numpy().tobytes()).hexdigest() == config["expected_input_sha256"]
residual = predict(theta, x) - y
jac = residual_jacobian(theta, x)
total_grad = jac.T @ residual / len(x)
checks = {"pb_sav": 0, "pb_esav": 0}
previous_groups = [torch.arange(len(x))]
for count in [8, 16, 30]:
    groups = nested_groups(len(x), count, config["partition_seed"])
    assert all(any(set(group.tolist()).issubset(set(parent.tolist()))
                   for parent in previous_groups) for group in groups)
    previous_groups = groups
    torch.testing.assert_close(torch.cat(groups).sort().values, torch.arange(len(x)))
    if count in [8, 30]:
        saved = json.loads((HERE / f"runs/r21/pb{count}/config.json").read_text())
        assert [group.tolist() for group in groups] == saved["group_indices"]
    energies, gradients = component_quantities(residual, jac, groups)
    torch.testing.assert_close(energies.sum(), residual.square().mean() / 2, rtol=1e-12, atol=1e-12)
    torch.testing.assert_close(gradients.sum(dim=1), total_grad, rtol=1e-12, atol=1e-12)
    assert (energies > 0).all()
    for method in ["pb_sav", "pb_esav"]:
        for offset in [0.0, -0.03]:
            for proposed_eta in [0.1, 1.0, 100.0]:
                parameter = theta.clone().requires_grad_(True)
                def loss_fn():
                    current = predict(parameter, x) - y
                    return [current[group].square().sum() / (2 * len(x)) for group in groups]
                if method == "pb_sav":
                    Q = (energies.sum() + config["shift"]).sqrt()
                    q = Q * (1 + offset)
                    ratio = q / Q
                    V = gradients / (2 * (energies + config["shift"] / count)).sqrt()
                else:
                    state = pb_esav.initialize(loss_fn())
                    state["log_r"] += offset
                    state["log_r_i"] += torch.linspace(offset, -offset, count)
                    ratio = (state["log_r"] - energies.sum() / (4 * state["initial_energy"])).exp()
                    component_ratios = (state["log_r_i"] - energies / (4 * state["initial_components"])).exp()
                    V = gradients * (component_ratios / (4 * state["initial_components"]).sqrt())
                force = gradients.sum(dim=1)
                trial, trial_energy, increment, eta, _ = accepted_step(
                    theta, x, y, energies.sum(), force, V, -ratio * force, proposed_eta, config)
                dense = torch.linalg.solve(torch.eye(len(theta)) + eta * (V @ V.T), -eta * ratio * force)
                torch.testing.assert_close(increment, dense, atol=1e-11, rtol=1e-9)
                if method == "pb_sav":
                    expected_aux = q + force @ increment / (2 * Q)
                    actual_aux = pb_sav.step([parameter], loss_fn, q, eta, config["shift"], relax=False)
                    torch.testing.assert_close(actual_aux, expected_aux, atol=1e-11, rtol=1e-9)
                    scalar_increment = expected_aux - q
                    B1 = torch.outer(force, force) / (2 * Q.square())
                    dissipation = (increment.square().sum() / eta + scalar_increment.square()
                                   + increment @ (V @ V.T - B1) @ increment)
                    torch.testing.assert_close(q.square() - expected_aux.square(), dissipation,
                                               atol=1e-11, rtol=1e-9)
                else:
                    expected_log = esav_auxiliary(state["log_r"], state["initial_energy"], ratio,
                                                   force, increment, trial_energy, False)
                    expected_components = state["log_r_i"] + component_ratios * (gradients.T @ increment) / (4 * state["initial_components"])
                    old_state = {key: value.clone() for key, value in state.items()}
                    actual_state = pb_esav.step([parameter], loss_fn, state, eta, relax=False)
                    torch.testing.assert_close(actual_state["log_r"], expected_log, atol=1e-11, rtol=1e-9)
                    torch.testing.assert_close(actual_state["log_r_i"], expected_components, atol=1e-11, rtol=1e-9)
                    for key in state:
                        torch.testing.assert_close(state[key], old_state[key], rtol=0, atol=0)
                    decrement = 4 * state["initial_energy"] * (expected_log - state["log_r"])
                    torch.testing.assert_close(decrement, -increment.square().sum() / eta - (V.T @ increment).square().sum(),
                                               atol=1e-11, rtol=1e-9)
                torch.testing.assert_close(parameter.detach(), trial, atol=1e-11, rtol=1e-9)
                checks[method] += 1
result = {"status": "passed", "training_performed": False, "same_r21_inputs": True,
          "nested_groups": [8, 16, 30], "r21_partitions_reused_exactly": [8, 30],
          "native_optimizer_step_checks": checks, "dissipation_checks": "passed",
          "relax": False, "controller_imported_unchanged": "c1_experiment.controlled_rate"}
(HERE / "pb_validation.json").write_text(json.dumps(result, indent=2))
print(json.dumps(result))
