"""Audit accepted run configurations and archived training loops; no training."""

import ast
import csv
import hashlib
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
os.environ["WANDB_SILENT"] = "true"
import tracking


def training_loop(source):
    """Extract the actual iteration loop independently of formatting and comments."""
    module = ast.parse(source)
    main = next(node for node in module.body if isinstance(node, ast.FunctionDef)
                and node.name == "main")
    block = next(node for node in main.body if isinstance(node, ast.Try))
    loop = next(node for node in block.body if isinstance(node, ast.For))
    return ast.dump(loop, include_attributes=False)


manifest = json.loads((HERE / "accepted_manifest.json").read_text())
target = HERE / "audit_r21"
target.mkdir(exist_ok=True)
sdk = tracking._sdk(ROOT)
api = sdk.Api(timeout=30)
methods = ["sav", "pb8", "pb30", "gn"]
defaults = {"controller": "warmstart", "initial_lr": 0.1, "growth": 1.1,
            "damping_safety": 1.0, "implicit_factor": 1.0, "retention_safety": False,
            "maximum_safety": 2.0, "growth_envelope": False, "armijo": 1e-4,
            "relax": False, "rho": 1.0}
result = {"scope": "accepted R21, not exploratory rounds", "training_performed": False,
          "methods": {}}
loops, policies, inputs, full_configs = [], [], [], []
for method in methods:
    record = manifest["runs"][method]
    folder = HERE / record["folder"]
    config = json.loads((folder / "config.json").read_text())
    run_id = record["wandb"].rstrip("/").split("/")[-1]
    archive = target / method
    artifact = api.artifact(
        f"pheonizard-university-of-nottingham/NumericalScheme/source-{run_id}:v0")
    artifact.download(root=str(archive))
    source_path = archive / "Challenge/fig3_reproduction/experiment.py"
    source = source_path.read_text()
    archived_config = json.loads((archive / "Challenge/fig3_reproduction/r21.json").read_text())
    assert all(config[key] == value for key, value in archived_config.items())
    remote_config = api.run(f"pheonizard-university-of-nottingham/NumericalScheme/{run_id}").config
    assert all(remote_config[key] == value for key, value in config.items())
    loop = training_loop(source)
    policy = {key: config.get(key, default) for key, default in defaults.items()}
    with (folder / "history.csv").open() as stream:
        rows = list(csv.DictReader(stream))
    rates = [float(row["lr"]) for row in rows[1:]]
    assert len(rates) == 600
    assert all(1e-6 <= value <= 100.0 for value in rates)
    result["methods"][method] = {
        "run_id": run_id, "policy": policy,
        "loop_sha256": hashlib.sha256(loop.encode()).hexdigest(),
        "source_sha256": hashlib.sha256(source.encode()).hexdigest(),
        "archived_source": str(source_path.relative_to(HERE)),
        "actual_lr_first": rates[0], "actual_lr_last": rates[-1],
        "actual_lr_min": min(rates), "actual_lr_max": max(rates),
        "total_armijo_backtracks": sum(int(row["backtracks"]) for row in rows),
        "input_sha256": config["input_sha256"],
    }
    loops.append(loop)
    policies.append(policy)
    inputs.append(config["input_sha256"])
    full_configs.append({key: value for key, value in config.items()
                         if key not in ["method", "group_indices"]})
result.update(
    archived_training_loops_identical=len(set(loops)) == 1,
    effective_policies_identical=all(policy == policies[0] for policy in policies),
    configs_equal_except_method_and_groups=all(config == full_configs[0] for config in full_configs),
    inputs_identical=len(set(inputs)) == 1,
    frozen_loop_matches_archives=training_loop((HERE / "accepted_experiment.py").read_text()) == loops[0],
)
assert all(result[key] for key in ["archived_training_loops_identical", "effective_policies_identical",
                                  "configs_equal_except_method_and_groups", "inputs_identical",
                                  "frozen_loop_matches_archives"])
(HERE / "learning_rate_audit.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
