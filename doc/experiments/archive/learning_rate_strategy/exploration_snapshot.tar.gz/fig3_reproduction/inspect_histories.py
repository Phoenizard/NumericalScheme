"""Summarize saved trajectories without rerunning optimization."""

import csv
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
for name in sys.argv[1:]:
    for method in ["sav", "pb8", "pb30", "gn"]:
        path = HERE / "runs" / name / method / "history.csv"
        if not path.exists():
            continue
        with path.open() as stream:
            rows = [{k: float(v) for k, v in row.items()} for row in csv.DictReader(stream)]
        result = {"round": name, "method": method,
                  "objective": {int(row["iteration"]): row["objective"] for row in rows
                                if int(row["iteration"]) in [50, 100, 200, 300, 400, 500, 600]}}
        for key in ["lr", "model_ratio", "armijo_ratio"]:
            if key in rows[0]:
                result[key + "_quantiles"] = np.quantile([r[key] for r in rows[1:]],
                                                        [0, .25, .5, .75, 1]).tolist()
        if "backtracks" in rows[0]:
            result["total_backtracks"] = sum(row["backtracks"] for row in rows)
        print(json.dumps(result))
