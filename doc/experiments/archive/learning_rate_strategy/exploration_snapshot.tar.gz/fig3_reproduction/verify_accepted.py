"""Verify the frozen inputs, equations and records without training."""

import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from accepted_experiment import initialize, load_data, verify

HERE = Path(__file__).resolve().parent
manifest = json.loads((HERE / "accepted_manifest.json").read_text())
config = json.loads((HERE / "accepted_config.json").read_text())
x, y = load_data(config)
theta = initialize(config)
input_hash = hashlib.sha256(torch.cat((x, y, theta)).numpy().tobytes()).hexdigest()
assert input_hash == manifest["input_sha256"]
saved = torch.load(HERE / "inputs/r21.pt", weights_only=True)
for key, regenerated in [("x", x), ("y", y), ("theta0", theta)]:
    torch.testing.assert_close(saved[key], regenerated, rtol=0, atol=0)
histories = {}
for method, record in manifest["runs"].items():
    folder = HERE / record["folder"]
    path = folder / "history.csv"
    assert hashlib.sha256(path.read_bytes()).hexdigest() == record["history_sha256"]
    with path.open() as stream:
        rows = list(csv.DictReader(stream))
    values = np.array([[float(value) for value in row.values()] for row in rows])
    assert len(rows) == 601 and np.isfinite(values).all()
    histories[method] = np.array([float(row["objective"]) for row in rows])
    if method != "gd":
        assert np.all(np.diff(histories[method]) <= 1e-14)
    if method in ["sav", "pb8", "pb30"]:
        run_config = json.loads((folder / "config.json").read_text())
        verify(theta, x, y, [torch.tensor(group) for group in run_config["group_indices"]])
for name, digest in manifest["frozen_files_sha256"].items():
    assert hashlib.sha256((HERE / name).read_bytes()).hexdigest() == digest
result = {"status": "passed", "training_performed": False,
          "input_regeneration": "bitwise_equal", "all_records_finite": True,
          "rows_per_method": 601, "first_order_gradient_and_pb_formula_checks": "passed",
          "pb30_gn_max_relative_objective_difference": float(
              np.max(np.abs(histories["pb30"] / histories["gn"] - 1))),
          "pb30_gn_final_absolute_objective_difference": float(
              abs(histories["pb30"][-1] - histories["gn"][-1]))}
(HERE / "accepted_verification.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
