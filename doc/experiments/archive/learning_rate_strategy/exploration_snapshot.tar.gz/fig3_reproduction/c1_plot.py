"""Plot six raw histories and audit shared inputs/policies without retraining."""

import csv
import hashlib
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
os.environ["MPLCONFIGDIR"] = str(HERE.parents[1] / "TMP/matplotlib")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


target = HERE / "runs/c1_sav_esav"
common = json.loads((HERE / "c1_config.json").read_text())
accepted = json.loads((HERE / "accepted_manifest.json").read_text())
policy_keys = ["controller", "initial_lr", "growth", "damping_safety", "implicit_factor",
               "retention_safety", "maximum_safety", "growth_envelope", "armijo"]
specifications = [
    ("sav", "SAV", "runs/c1_sav_esav/sav", "#0072B2", "-", "o"),
    ("esav", "ESAV", "runs/c1_sav_esav/esav", "#D55E00", "-.", "^"),
    ("relax_sav", "Relax-SAV", "runs/r21/sav", "#7B3F98", "--", "s"),
    ("relax_esav", "Relax-ESAV", "runs/c1_sav_esav/relax_esav", "#E69F00", ":", "v"),
    ("gd", "GD (fixed lr = 0.22)", "runs/r08/gd", "#009E73", "--", "D"),
    ("adam", "Adam (fixed lr = 0.03)", "runs/c1_sav_esav/adam", "#242424", "-", "x"),
]
plt.rcParams.update({"font.size": 11, "axes.titlesize": 14})
fig, ax = plt.subplots(figsize=(10, 6.3), layout="constrained")
fig.suptitle("Nonlinear regression: SAV, ESAV and Relax", fontsize=14)
report = {"shared_input_sha256": common["expected_input_sha256"],
          "shared_controller_parameters": {key: common[key] for key in policy_keys},
          "curves": {}, "smoothing": False, "numerical_axis_transform": False}
for index, (key, label, relative, color, style, marker) in enumerate(specifications):
    folder = HERE / relative
    config = json.loads((folder / "config.json").read_text())
    summary = json.loads((folder / "summary.json").read_text())
    assert config["input_sha256"] == common["expected_input_sha256"]
    digest = hashlib.sha256((folder / "history.csv").read_bytes()).hexdigest()
    if key in ["gd", "relax_sav"]:
        assert digest == accepted["runs"]["sav" if key == "relax_sav" else key]["history_sha256"]
    with (folder / "history.csv").open() as stream:
        rows = list(csv.DictReader(stream))
    iterations = np.array([int(row["iteration"]) for row in rows])
    values = np.array([float(row["objective"]) for row in rows])
    rates = np.array([float(row["lr"]) for row in rows[1:]])
    assert np.array_equal(iterations, np.arange(len(rows)))
    if summary["status"] == "completed":
        assert len(rows) == 601 and np.isfinite(values).all()
    else:
        label += f" (failed at {iterations[-1]})"
    if key not in ["gd", "adam"]:
        assert all(config.get(field, common[field]) == common[field] for field in policy_keys)
        assert np.all((rates >= 1e-6) & (rates <= 100.0))
        assert config["relax"] == key.startswith("relax_")
    else:
        assert np.all(rates == (0.22 if key == "gd" else 0.03))
    ax.semilogy(iterations, values, label=label, color=color, linestyle=style,
                linewidth=1.9, marker=marker, markersize=4.8, markerfacecolor="white",
                markeredgewidth=1.15, markevery=(8 * index, 60))
    report["curves"][key] = dict(source=relative, history_sha256=digest,
                                reused=key in ["gd", "relax_sav"], **summary)
ax.set(xlabel="Iteration", ylabel="Training objective", xlim=(0, 600))
ax.grid(True, which="major", alpha=0.23)
ax.grid(True, which="minor", alpha=0.10)
ax.legend(loc="lower left", bbox_to_anchor=(0, 1.09), ncol=3, fontsize=10,
          handlelength=3, columnspacing=2, framealpha=1)
ax.text(0, 1.02, "SAV / ESAV: shared R21 adaptive controller    |    GD / Adam: fixed learning rates",
        transform=ax.transAxes, fontsize=9, color="#555555")
fig.savefig(target / "sav_esav_relax_adam.png", dpi=190)
fig.savefig(target / "sav_esav_relax_adam.pdf")
(target / "comparison.json").write_text(json.dumps(report, indent=2))
print(json.dumps({"image": str(target / "sav_esav_relax_adam.png"),
                  "six_curves": len(report["curves"]), "shared_inputs_and_policies": "passed",
                  "objectives": {key: value["objective"] for key, value in report["curves"].items()}}))
