# Figure 3：已接受版本 R21

2026-10-30，用户确认R21完整结果图可以接受。本次交付范围为Figure 3的图形复现。原图来自本地`doc/paper/PB_SAV_Momentum.pdf`，§4.2，对照版本arXiv:2609.13569v1。

- 图：[accepted_figure3.png](accepted_figure3.png)
- 冻结代码：[accepted_experiment.py](accepted_experiment.py)
- 完整配置：[accepted_config.json](accepted_config.json)
- 原始记录路径、W&B链接和文件校验值：[accepted_manifest.json](accepted_manifest.json)
- 不重跑训练的核查结果：[accepted_verification.json](accepted_verification.json)
- 所有探索轮次及未披露设置的选择依据：[protocol.md](protocol.md)
- 学习率一致性复核（含W&B实际源码快照）：[learning_rate_audit.json](learning_rate_audit.json)

## 学习率一致性复核

已从W&B读取SAV、PB8、PB30、GN四次R21运行的实际源码快照及在线配置，并与本地运行记录交叉核对。四次运行的训练循环抽象语法树完全一致；有效控制器参数完全一致；完整运行配置仅method和group_indices不同；数据和初值hash相同。冻结代码的训练循环也与这些历史快照一致。不同完整源码文件的差异来自新增单步公式检查及日志静默设置，训练循环未改变。

同一自适应规则会根据各自状态和B产生不同的学习率序列：三种SAV的首步接受η依次约0.265009、0.681650、1；这不是分别设置的初始值。共同初始试探上限为1，先受当前曲率上界约束。R21四次运行均通过首次Armijo检查，实际回溯次数全部为0。

## 问题和初值

30个等距训练点，目标为sin(2πx)，独立高斯噪声标准差0.1，NumPy RandomState种子42。网络为1–50–1 tanh，共151个参数；训练目标为残差平方和/(2N)。CPU、float64，全批量，600次接受更新，包含iteration=0。

初始化使用PyTorch生成器种子42：隐藏斜率a=0.72×N(0,1)，偏置b=-a/2；输出权重c=N(0,1)/√50，输出偏置为0。初始相关性不约束训练，所有参数独立更新。数据和初值在五条曲线间逐位相同，输入hash见manifest。

PB分组使用NumPy RandomState(42)的一次随机排列，反复将最大组二分，形成嵌套划分。每组能量为组内残差平方和/(2N)。总shift C=1e-10，各组C_i=C/m。

## 参数更新和学习率

GD固定η=0.22。SAV/PB-SAV使用原文式(19)、α=1；辅助变量初值q=√(F+C)，并使用式(45)的全Relax，ρ=1。Gauss–Newton使用同样的线性系统形式，将PB矩阵替换为G=JᵀJ/N，其中J是网络输出的一阶Jacobian。

所有SAV/PB-SAV和GN共用以下控制器。设当前矩阵为B（GN取B=G），曲率保留比例t=tr(B)/tr(G)，则

\[
\eta_{\mathrm{bound}}
=\operatorname{clip}\!\left(
\frac{0.5+0.5t}{\max\{\lambda_{\max}(G-2B),10^{-12}\}},
10^{-6},100\right).
\]

第一次试探η=min(1,η_bound)；之后试探η=min(1.1×上次接受η,η_bound)。使用Armijo判据

\[
F(\theta+\Delta)\le F(\theta)+10^{-4}\nabla F(\theta)^T\Delta.
\]

拒绝时η减半，重新求解式(19)，参数和辅助状态不更新；接受后更新参数，再执行辅助状态Relax。拒绝的试探不计入600次更新。控制器额外使用逐样本一阶Jacobian，没有计算Hessian、Hessian–向量积或二阶自动微分。

数据实现、初始化、分组种子、shift、Relax以及具体阻尼控制器属于原文未明确披露部分的复现选择；初始化尺度和控制器参数经过参考图指导的校准。它们不是已确认的作者设置。

## 原始结果

| 曲线 | 原始轮次 | 第600步目标值 |
| --- | --- | --- |
| SAV | R21 | 0.05921365697257935 |
| GD | R08，共同数据和初值 | 0.030498330967106812 |
| PB-SAV 8 | R21 | 0.00841371872573852 |
| PB-SAV 30 | R21 | 0.002538677683417507 |
| Gauss–Newton | R21 | 0.0025386776778311454 |

图由原始CSV直接绘制，无平滑、纵横轴数值重标或手工移动。每条记录均有601行、全部有限；SAV/PB/GN的接受目标值单调非增。逐样本梯度、小矩阵求解与原文式(20)耗散恒等式已检查。PB30与GN最终目标绝对差约5.59e-12。

本版按用户图形审核接受；原自动审核结果保留，不改写为全部通过。仍有PB8中段速度、PB30转折位置以及Table 2梯度范数等数值差异。该验收不代表恢复了论文的全部隐藏设置，也不代表§4.1或整篇论文已经完成。

## 运行

在项目根目录、numenv环境中，以下命令只核查记录和单步公式，不训练：

```sh
python -B Challenge/fig3_reproduction/verify_accepted.py
```

需要重新训练时，每次只运行一个方法；将`sav`依次替换为`gd`、`pb8`、`pb30`或`gn`：

```sh
python -B Challenge/fig3_reproduction/accepted_experiment.py --config Challenge/fig3_reproduction/accepted_config.json --method sav
```

训练开始前必须连接W&B。输出写入`Challenge/fig3_reproduction/runs/accepted_config/`，已有记录会拒绝覆盖。重放输入的hash须与接受版本完全相同。所有方法完成后，从新记录绘图：

```sh
python -B Challenge/fig3_reproduction/review.py accepted_config
```
