"""Freeze the user-accepted R21 result without running training."""

import csv
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
origins = {"sav": "r21", "gd": "r08", "pb8": "r21", "pb30": "r21", "gn": "r21"}
manifest = {
    "status": "user_accepted_figure3",
    "selected_round": "r21",
    "user_acceptance": "如果现在你展示出的第二张图是你自己画的，那我觉得完全可以。",
    "scope": "Figure 3 visual reproduction; not exact recovery of the authors' undisclosed settings or Table 2",
    "plot": "runs/r21/review.png",
    "reference_plot": "figure3_reference.png",
    "automated_review": "runs/r21/review.json",
    "preserve_automated_failures": True,
    "runs": {},
}
hashes = set()
for method, origin in origins.items():
    folder = HERE / "runs" / origin / method
    config = json.loads((folder / "config.json").read_text())
    summary = json.loads((folder / "summary.json").read_text())
    with (folder / "history.csv").open() as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 601
    assert [int(row["iteration"]) for row in rows] == list(range(601))
    hashes.add(config["input_sha256"])
    manifest["runs"][method] = {
        "folder": str(folder.relative_to(HERE)),
        "history_sha256": hashlib.sha256((folder / "history.csv").read_bytes()).hexdigest(),
        "wandb": summary["url"],
        "objective": summary["objective"],
        "best_test_mse": summary["best_test_mse"],
        "gradient_norm": summary["gradient_norm"],
    }
assert len(hashes) == 1
config = json.loads((HERE / "r21.json").read_text())
config.pop("reuse")
config.update(round="accepted_config", expected_input_sha256=next(iter(hashes)),
              armijo=1e-4, rho=1.0)
(HERE / "accepted_config.json").write_text(json.dumps(config, indent=2) + "\n")
shutil.copyfile(HERE / "experiment.py", HERE / "accepted_experiment.py")
shutil.copyfile(HERE / "runs/r21/review.png", HERE / "accepted_figure3.png")
manifest["input_sha256"] = next(iter(hashes))
manifest["frozen_files_sha256"] = {
    name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
    for name in ["accepted_experiment.py", "accepted_config.json", "accepted_figure3.png"]
}
(HERE / "accepted_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"status": manifest["status"], "methods": list(origins),
                  "same_inputs": len(hashes) == 1}))
