"""Compute data diagnostics without running an optimizer."""

import json
from experiment import load_data, torch, HERE

result={}
for label,config in [("existing",{"data":"existing"}),
                     ("numpy42",{"data":"numpy","data_seed":42}),
                     ("numpy_legacy42",{"data":"numpy_legacy","data_seed":42})]:
    x,y=load_data(config)
    design=torch.stack([x,torch.ones_like(x)],dim=1)
    residual=design@torch.linalg.lstsq(design,y).solution-y
    noise=y-torch.sin(2*torch.pi*x)
    result[label]={"best_affine_objective":residual.square().mean().item()/2,
                   "realized_noise_std":noise.std().item()}
(HERE/"data_diagnostics.json").write_text(json.dumps(result,indent=2))
print(json.dumps(result))
