"""Render an honest partial/full round and evaluate predeclared acceptance criteria."""

import argparse
import csv
import json
import os
from pathlib import Path

HERE=Path(__file__).resolve().parent
os.environ["MPLCONFIGDIR"]=str(HERE.parents[1]/"TMP/matplotlib")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

parser=argparse.ArgumentParser()
parser.add_argument("round")
args=parser.parse_args()
folder=HERE/"runs"/args.round
config=json.loads((HERE/(args.round+".json")).read_text())
plt.rcParams.update({"font.size": 9})
fig,ax=plt.subplots(figsize=(6.8,4.05),layout="constrained")
assessment={"round":args.round,"complete_figure":False}
reference=json.loads((HERE/"reference_points.json").read_text())
curves={}
hashes={}
maximum=0.35
for method,label,color,style,marker in [
    ("sav","SAV (1 aggregate component)","#008dcc","-.","s"),
    ("pb8","PB-SAV (8 groups)","#e3a200","--","^"),
    ("pb30","PB-SAV (30 pointwise components)","#ed2828","-","o"),
    ("gd","Gradient descent (selected lr = 0.22)","#00a98d",":","D"),
    ("gn","Damped Gauss–Newton","#222222",":","x"),
]:
    origin=config.get("reuse",{}).get(method,args.round)
    path=HERE/"runs"/origin/method/"history.csv"
    if not path.exists():
        continue
    with path.open() as stream:
        rows=list(csv.DictReader(stream))
    xs=[int(r["iteration"]) for r in rows]
    ys=[float(r["objective"]) for r in rows]
    maximum=max(maximum,1.05*max(ys))
    ax.semilogy(xs,ys,label=label,color=color,linestyle=style,linewidth=1.2,
                marker=marker,markersize=3.5,markerfacecolor="white",markevery=60)
    curves[method]=np.array(ys)
    run_config=json.loads(path.with_name("config.json").read_text())
    hashes[method]=run_config["input_sha256"]
    assessment[method]={"final":ys[-1],"steps":xs[-1],"source_round":origin}
    if xs[-1]==600:
        assessment[method]["checkpoints"]={str(i):ys[i] for i in [0,50,100,200,300,400,500,600]}
        if method in reference:
            assessment[method]["reference_relative_errors"]={
                step:ys[int(step)]/value-1 for step,value in reference[method].items()}
    if method=="gd" and xs[-1]==600:
        assessment[method]["pass"]=bool(abs(ys[-1]/0.03301-1)<=0.1 and
                0.085<=ys[100]<=0.110 and 0.075<=ys[200]<=0.100 and 0.050<=ys[400]<=0.080)
        assessment[method]["checkpoints"]={str(i):ys[i] for i in [0,50,100,200,400,600]}
if all(method in curves and len(curves[method])==601 for method in ["sav","pb8","pb30","gd","gn"]):
    assessment["complete_figure"]=True
    checks={"same_inputs":len(set(hashes.values()))==1,
            "sav_final":0.05<=curves["sav"][-1]<=0.075,
            "gd":assessment["gd"]["pass"],
            "pb8_final":0.006<=curves["pb8"][-1]<=0.009,
            "pb8_sustained_descent":curves["pb8"][400]<0.8*curves["pb8"][200]
                                     and curves["pb8"][600]<0.8*curves["pb8"][400],
            "pb30_final":abs(curves["pb30"][-1]/0.002525-1)<=0.1,
            "gn_final":abs(curves["gn"][-1]/0.002525-1)<=0.1,
            "final_order":curves["sav"][-1]>curves["gd"][-1]>curves["pb8"][-1]>curves["pb30"][-1],
            "pb30_gn_overlap":np.max(np.abs(np.log(curves["pb30"]/curves["gn"])))<0.002}
    hits=np.flatnonzero(curves["pb30"]<0.004)
    assessment["pb30_first_below_0.004"]=int(hits[0]) if len(hits) else None
    checks["pb30_transition"]=bool(len(hits) and 40<=hits[0]<=100)
    assessment["checks"]={k:bool(v) for k,v in checks.items()}
    assessment["predeclared_figure_pass"]=all(checks.values())
    assessment["sampled_curve_agreement"]=all(
        abs(error)<=0.2 for method in ["sav","pb8","pb30","gd"]
        for error in assessment[method]["reference_relative_errors"].values())
    assessment["approximate_figure_pass"]=(assessment["predeclared_figure_pass"]
                                            and assessment["sampled_curve_agreement"])
ax.set(xlabel="Accepted updates",ylabel="Training objective",xlim=(0,600),ylim=(0.002,maximum),
       )
ax.grid(True,which="both",alpha=0.18)
if maximum>1e100:
    from matplotlib.ticker import FixedLocator, NullLocator
    ax.yaxis.set_major_locator(FixedLocator([10.0**i for i in [-2,0,50,100,150,200,250,300]]))
    ax.yaxis.set_minor_locator(NullLocator())
ax.legend(loc="lower left",bbox_to_anchor=(0,1.02),fontsize=7,ncol=2)
fig.savefig(folder/"review.png",dpi=180)
(folder/"review.json").write_text(json.dumps(assessment,indent=2))
print(json.dumps(assessment))
