"""One auditable Figure 3 experiment per invocation; first derivatives only."""

import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
os.environ["TMPDIR"] = str(ROOT / "TMP")
os.environ["MPLCONFIGDIR"] = str(ROOT / "TMP/matplotlib")
os.environ["WANDB_SILENT"] = "true"

import numpy as np
import torch
import tracking
from problem.nonlinear_regression import make_groups

torch.set_num_threads(4)
torch.set_default_dtype(torch.float64)


def predict(theta, x):
    """Evaluate equation (68)."""
    return torch.tanh(x[:, None] * theta[:50] + theta[50:100]) @ theta[100:150] + theta[150]


def residual_jacobian(theta, x):
    """Analytic first derivatives of network output with respect to 151 parameters."""
    hidden = torch.tanh(x[:, None] * theta[:50] + theta[50:100])
    derivative = (1 - hidden.square()) * theta[100:150]
    return torch.cat((derivative * x[:, None], derivative, hidden,
                      torch.ones((len(x), 1))), dim=1)


def initialize(config):
    """Use explicitly recorded, deterministic initialization hypotheses."""
    generator = torch.Generator().manual_seed(config["init_seed"])
    if config["init"] == "centered_normal":
        theta = torch.zeros(151)
        theta[:50] = torch.randn(50, generator=generator)
        theta[50:100] = -0.5 * theta[:50]
        theta[100:150] = torch.randn(50, generator=generator)/math.sqrt(50)
    elif config["init"] == "normal":
        theta = torch.randn(151, generator=generator)
        theta[100:] /= math.sqrt(50)
    elif config["init"] == "uniform":
        theta = 2 * torch.rand(151, generator=generator) - 1
        theta[100:] /= math.sqrt(50)
    elif config["init"] in ("torch_default", "xavier"):
        torch.manual_seed(config["init_seed"])
        hidden = torch.nn.Linear(1, 50)
        output = torch.nn.Linear(50, 1)
        if config["init"] == "xavier":
            torch.nn.init.xavier_uniform_(hidden.weight, gain=5/3)
            torch.nn.init.zeros_(hidden.bias)
            torch.nn.init.xavier_uniform_(output.weight)
            torch.nn.init.zeros_(output.bias)
        theta = torch.cat([p.detach().flatten() for p in (*hidden.parameters(), *output.parameters())])
    else:
        raise ValueError(config["init"])
    theta[:100] *= config.get("hidden_scale", 1.0)
    return theta


def load_data(config):
    """Load unchanged existing data unless a documented data hypothesis is selected."""
    if config.get("data", "existing") == "existing":
        data = torch.load(ROOT / "data/nonlinear_regression.pt", weights_only=True)
        return data["x_train"].flatten(), data["y_train"].flatten()
    rng = (np.random.RandomState(config.get("data_seed",42))
           if config["data"]=="numpy_legacy" else np.random.default_rng(config.get("data_seed", 1)))
    x = np.linspace(0, 1, 30)
    y = np.sin(2 * np.pi * x) + 0.1 * rng.standard_normal(30)
    return torch.tensor(x), torch.tensor(y)


def verify(theta, x, y, groups):
    """Validate forward map, gradients, component normalization and scalar SAV solve."""
    t = theta.clone().requires_grad_(True)
    energy = (predict(t, x) - y).square().mean() / 2
    grad = torch.autograd.grad(energy, t)[0]
    jac = residual_jacobian(theta, x)
    analytic = jac.T @ (predict(theta, x) - y) / len(x)
    torch.testing.assert_close(grad, analytic, atol=1e-12, rtol=1e-12)
    residual = predict(theta, x) - y
    torch.testing.assert_close(sum(residual[g].square().sum() for g in groups) / (2*len(x)),
                               energy.detach())
    q = (energy.detach() + 1e-10).sqrt()
    eta = 0.1
    q_next = q / (1 + eta * grad.square().sum() / (2*q.square()))
    step = -eta * q_next / q * grad
    torch.testing.assert_close(q_next, q + grad @ step / (2*q))
    torch.testing.assert_close(torch.cat(groups).sort().values, torch.arange(len(x)))
    energies = torch.stack([residual[group].square().sum() / (2 * len(x)) for group in groups])
    gradients = torch.stack([jac[group].T @ residual[group] / len(x) for group in groups], dim=1)
    factor = gradients / torch.sqrt(2 * (energies + 1e-10 / len(groups)))
    curvature = factor @ factor.T
    aggregate = torch.outer(grad, grad) / (2 * q.square())
    for rate in [0.1, 1.0, 10.0, 100.0]:
        rhs = -rate * grad
        increment = rhs - rate * factor @ torch.linalg.solve(
            torch.eye(len(groups)) + rate * (factor.T @ factor), factor.T @ rhs)
        dense = torch.linalg.solve(torch.eye(len(theta)) + rate * curvature, rhs)
        torch.testing.assert_close(increment, dense, atol=1e-11, rtol=1e-9)
        scalar_increment = grad @ increment / (2 * q)
        dissipation = (increment.square().sum() / rate + scalar_increment.square()
                       + increment @ (curvature - aggregate) @ increment)
        torch.testing.assert_close(q.square() - (q + scalar_increment).square(),
                                   dissipation, atol=1e-11, rtol=1e-9)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--method", choices=["gd", "sav", "pb8", "pb30", "gn", "adam"], required=True)
    args = parser.parse_args()
    config_path = Path(args.config).resolve()
    config = json.loads(config_path.read_text())
    config.update(method=args.method, source_version="2609.13569v1", dtype="float64",
                  device="cpu", batch_policy="full_batch", steps=600)
    target = HERE / "runs" / config["round"] / args.method
    if (target / "history.csv").exists():
        raise ValueError("Refusing to overwrite a completed or partial run")
    target.mkdir(parents=True, exist_ok=True)
    x, y = load_data(config)
    theta = initialize(config)
    m = {"sav": 1, "pb8": 8, "pb30": 30}.get(args.method, 1)
    groups = make_groups(30, m, config.get("partition_seed", 3))
    if config.get("partition_rng") in ("numpy", "numpy_recursive"):
        partition_generator = np.random.RandomState(config["partition_seed"])
        groups=[torch.tensor(partition_generator.permutation(30))]
        while len(groups)<m:
            index=max(range(len(groups)),key=lambda i:len(groups[i]))
            if config.get("partition_rng") == "numpy_recursive":
                groups[index] = groups[index][partition_generator.permutation(len(groups[index]))]
            groups[index:index+1]=list(groups[index].tensor_split(2))
    verify(theta, x, y, groups)
    data_path = HERE / "inputs" / (config["round"] + ".pt")
    data_path.parent.mkdir(exist_ok=True)
    if not data_path.exists():
        torch.save({"x": x, "y": y, "theta0": theta}, data_path)
    config.update(data_path=str(data_path),
                  input_sha256=hashlib.sha256(torch.cat((x,y,theta)).numpy().tobytes()).hexdigest(),
                  group_indices=[g.tolist() for g in groups])
    expected = config.get("expected_input_sha256")
    if expected and expected != config["input_sha256"]:
        raise ValueError("Regenerated data or initial parameters do not match the accepted run")
    sdk = tracking._sdk(ROOT)
    remote = sdk.init(entity="pheonizard-university-of-nottingham", project="NumericalScheme",
                      name=f"fig3_{config['round']}_{args.method}", mode="online", config=config,
                      settings=sdk.Settings(init_timeout=30, finish_timeout=60,
                                            disable_git=True, save_code=False, x_disable_meta=True))
    if remote is None or remote.offline or remote.disabled:
        raise RuntimeError("Online recording required before training")
    source = sdk.Artifact(f"source-{remote.id}", type="experiment-source")
    for path in [Path(__file__), config_path, HERE / "protocol.md",
                 ROOT / "problem/nonlinear_regression.py", ROOT / "tracking.py"]:
        source.add_file(str(path), name=str(path.relative_to(ROOT)))
    remote.log_artifact(source)
    remote.define_metric("iteration")
    remote.define_metric("*", step_metric="iteration")
    q = ((predict(theta, x)-y).square().mean()/2 + config.get("shift",1e-10)).sqrt()
    eta = config.get("initial_lr", 0.1)
    rows = []
    ratio = 0.0
    armijo_ratio = 0.0
    backtracks = 0
    best_test = float("inf")
    test_x = torch.linspace(0,1,1001)
    adam_theta = theta.clone().requires_grad_(True)
    adam = torch.optim.Adam([adam_theta], lr=0.03) if args.method == "adam" else None
    status = "completed"
    try:
        for iteration in range(601):
            residual = predict(theta, x)-y
            jac = residual_jacobian(theta, x)
            energy = residual.square().mean()/2
            grad = jac.T @ residual / len(x)
            test = (predict(theta,test_x)-torch.sin(2*torch.pi*test_x)).square().mean().item()
            best_test = min(best_test,test)
            row = dict(iteration=iteration, objective=energy.item(), gradient_norm=grad.norm().item(),
                       test_mse=test, q=q.item(), q_current=(energy+config.get("shift",1e-10)).sqrt().item(),
                       lr=0 if iteration==0 else accepted_lr, model_ratio=ratio,
                       armijo_ratio=armijo_ratio, backtracks=backtracks)
            if not all(math.isfinite(v) for v in row.values()):
                raise FloatingPointError(str(row))
            rows.append(row)
            remote.log(row, step=iteration)
            if iteration==600:
                break
            if args.method=="gd":
                theta = theta - 0.22*grad
                accepted_lr = 0.22
                continue
            if adam is not None:
                adam.zero_grad()
                loss=(predict(adam_theta,x)-y).square().mean()/2
                loss.backward()
                adam.step()
                theta=adam_theta.detach().clone()
                accepted_lr=0.03
                continue
            Q=(energy+config.get("shift",1e-10)).sqrt()
            if args.method=="gn":
                V=jac.T/math.sqrt(len(x))
                rhs=-grad
            else:
                energies=torch.stack([residual[g].square().sum()/(2*len(x)) for g in groups])
                gradients=torch.stack([jac[g].T@residual[g]/len(x) for g in groups],dim=1)
                V=gradients/torch.sqrt(2*(energies+config.get("shift",1e-10)/m))
                rhs=-(q/Q)*grad
            if config.get("controller")=="curvature_gap":
                gauss_newton = jac.T @ jac / len(x)
                pullback = V @ V.T
                missing=gauss_newton-config.get("implicit_factor",1.0)*pullback
                largest=torch.linalg.eigvalsh(missing)[-1].item()
                safety = config.get("damping_safety", 1.0)
                if config.get("retention_safety", False):
                    retained = (torch.trace(pullback) / torch.trace(gauss_newton)).item()
                    safety += (config.get("maximum_safety", 2.0) - safety) * min(1.0, max(0.0, retained))
                bound = min(100.0, max(1e-6, safety / max(largest, 1e-12)))
                eta = min(eta, bound) if config.get("growth_envelope", False) else bound
            backtracks = 0
            while True:
                increment=eta*rhs-eta*V@torch.linalg.solve(
                    torch.eye(V.shape[1])+eta*(V.T@V), V.T@(eta*rhs))
                trial=theta+increment
                trial_energy=(predict(trial,x)-y).square().mean()/2
                if torch.isfinite(trial_energy) and trial_energy <= energy+config.get("armijo", 1e-4)*(grad@increment):
                    break
                if eta<=1e-6:
                    raise FloatingPointError("Armijo failed at minimum rate")
                eta=max(1e-6,eta*0.5)
                backtracks += 1
            armijo_ratio = ((energy-trial_energy)/(-grad@increment)).item()
            q_trial=q+grad@increment/(2*Q)
            if config.get("relax",False):
                rho=config.get("rho",1.0)
                q=torch.minimum(trial_energy+config.get("shift",1e-10),
                                q_trial.square()+rho*(q.square()-q_trial.square())).sqrt()
            else:
                q=q_trial
            theta=trial
            accepted_lr=eta
            if config.get("controller","warmstart")=="model_ratio":
                predicted=-grad@increment-0.5*(V.T@increment).square().sum()
                ratio=((energy-trial_energy)/predicted).item() if predicted>0 else 0.0
                if ratio<config.get("ratio_low",0.25):
                    eta=max(1e-6,eta*0.5)
                elif ratio>config.get("ratio_high",0.75):
                    eta=min(100.0,eta*config.get("growth",1.1))
            else:
                eta=min(100.0,eta*config.get("growth",1.1))
    except BaseException as error:
        status="failed"
        (target/"failure.txt").write_text(repr(error))
        raise
    finally:
        with (target/"history.csv").open("w",newline="") as stream:
            writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        summary=dict(status=status, best_test_mse=best_test, **rows[-1], url=remote.url)
        (target/"summary.json").write_text(json.dumps(summary,indent=2))
        (target/"config.json").write_text(json.dumps(config,indent=2))
        remote.summary.update(summary)
        records=sdk.Artifact(f"records-{remote.id}",type="experiment-record")
        for path in target.glob("*.*"):
            records.add_file(str(path), name=path.name)
        remote.log_artifact(records)
        remote.finish(exit_code=0 if status=="completed" else 1)
    print(json.dumps(summary))


if __name__=="__main__":
    main()
