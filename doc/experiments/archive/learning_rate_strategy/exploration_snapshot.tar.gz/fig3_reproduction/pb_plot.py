"""Add six non-relaxed PB histories to the four unchanged C1 reference curves."""

import csv
import hashlib
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
os.environ["MPLCONFIGDIR"] = str(HERE.parents[1] / "TMP/matplotlib")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


target = HERE / "runs/d1_pb_no_relax"
common = json.loads((HERE / "c1_config.json").read_text())
old_plot = json.loads((HERE / "runs/c1_sav_esav/comparison.json").read_text())
policy_keys = ["controller", "initial_lr", "growth", "damping_safety", "implicit_factor",
               "retention_safety", "maximum_safety", "growth_envelope", "armijo"]
specifications = [
    ("sav", "SAV", "runs/c1_sav_esav/sav", "#0072B2", "-", "o"),
    ("esav", "ESAV", "runs/c1_sav_esav/esav", "#D55E00", "-.", "^"),
    ("gd", "SGD / GD (lr = 0.22)", "runs/r08/gd", "#009E73", "--", "D"),
    ("adam", "Adam (lr = 0.03)", "runs/c1_sav_esav/adam", "#242424", "-", "x"),
    ("pb_sav_m8", "PB-SAV (8 groups)", "runs/d1_pb_no_relax/pb_sav_m8", "#9467BD", "-", "s"),
    ("pb_esav_m8", "PB-ESAV (8 groups)", "runs/d1_pb_no_relax/pb_esav_m8", "#9467BD", "--", "^"),
    ("pb_sav_m16", "PB-SAV (16 groups)", "runs/d1_pb_no_relax/pb_sav_m16", "#00A6B2", "-", "s"),
    ("pb_esav_m16", "PB-ESAV (16 groups)", "runs/d1_pb_no_relax/pb_esav_m16", "#00A6B2", "--", "^"),
    ("pb_sav_m30", "PB-SAV (30 groups)", "runs/d1_pb_no_relax/pb_sav_m30", "#CC3366", "-", "s"),
    ("pb_esav_m30", "PB-ESAV (30 groups)", "runs/d1_pb_no_relax/pb_esav_m30", "#CC3366", "--", "^"),
]
plt.rcParams.update({"font.size": 11})
fig, ax = plt.subplots(figsize=(12.6, 7.3), layout="constrained")
fig.suptitle("Nonlinear regression: SAV / ESAV with PB components", fontsize=15)
report = {"shared_input_sha256": common["expected_input_sha256"], "relax": False,
          "shared_controller": {key: common[key] for key in policy_keys},
          "gd_label": "SGD / GD denotes the unchanged full-batch GD record; no stochastic resampling",
          "curves": {}, "smoothing": False}
for index, (key, label, relative, color, style, marker) in enumerate(specifications):
    folder = HERE / relative
    config = json.loads((folder / "config.json").read_text())
    summary = json.loads((folder / "summary.json").read_text())
    assert config["input_sha256"] == common["expected_input_sha256"]
    digest = hashlib.sha256((folder / "history.csv").read_bytes()).hexdigest()
    reused = key in ["sav", "esav", "gd", "adam"]
    if reused:
        assert digest == old_plot["curves"][key]["history_sha256"]
    with (folder / "history.csv").open() as stream:
        rows = list(csv.DictReader(stream))
    iterations = np.array([int(row["iteration"]) for row in rows])
    values = np.array([float(row["objective"]) for row in rows])
    rates = np.array([float(row["lr"]) for row in rows[1:]])
    assert np.array_equal(iterations, np.arange(len(rows)))
    if summary["status"] == "completed":
        assert len(rows) == 601 and np.isfinite(values).all()
    else:
        label += f" [failed: {iterations[-1]}]"
    if key not in ["gd", "adam"]:
        assert config["relax"] is False
        assert all(config.get(field, common[field]) == common[field] for field in policy_keys)
        assert np.all((rates >= 1e-6) & (rates <= 100.0))
        if summary["status"] == "completed":
            auxiliary = np.array([float(row["auxiliary_energy"]) for row in rows])
            assert np.isfinite(auxiliary).all()
            assert np.max(np.diff(values)) <= 1e-12
            assert np.max(np.diff(auxiliary)) <= 1e-12
    else:
        assert np.all(rates == (0.22 if key == "gd" else 0.03))
    ax.semilogy(iterations, values, label=label, color=color, linestyle=style,
                linewidth=1.8, marker=marker, markersize=4.5, markerfacecolor="white",
                markeredgewidth=1.05, markevery=(5 * index, 75))
    if summary["status"] != "completed":
        finite = np.flatnonzero(np.isfinite(values))
        if len(finite):
            last = finite[-1]
            ax.plot(iterations[last], values[last], marker="X", color=color, markersize=8)
    report["curves"][key] = dict(source=relative, history_sha256=digest, reused=reused, **summary)
for count in [8, 16, 30]:
    sav_config = json.loads((target / f"pb_sav_m{count}/config.json").read_text())
    esav_config = json.loads((target / f"pb_esav_m{count}/config.json").read_text())
    assert sav_config["group_indices"] == esav_config["group_indices"]
ax.set(xlabel="Iteration", ylabel="Training objective", xlim=(0, 600))
ax.grid(True, which="major", alpha=0.23)
ax.grid(True, which="minor", alpha=0.10)
ax.legend(loc="lower left", bbox_to_anchor=(0, 1.08), ncol=5, fontsize=9,
          handlelength=2.6, columnspacing=1.3, framealpha=1)
ax.text(0, 1.02, "No Relax, full batch  |  SAV / ESAV / PB: shared R21 controller  |  SGD / GD and Adam: fixed learning rates",
        transform=ax.transAxes, fontsize=9, color="#555555")
fig.savefig(target / "sav_esav_pb_8_16_30.png", dpi=190)
fig.savefig(target / "sav_esav_pb_8_16_30.pdf")
(target / "comparison.json").write_text(json.dumps(report, indent=2))
print(json.dumps({"image": str(target / "sav_esav_pb_8_16_30.png"),
                  "curves": len(report["curves"]), "unchanged_reused_curves": 4,
                  "shared_inputs_partitions_and_policies": "passed",
                  "results": {key: {"status": value["status"], "objective": value["objective"],
                                    "iterations": value["iteration"]}
                              for key, value in report["curves"].items()}}))
