"""Inspect existing initial states without performing optimizer updates."""

import json
from pathlib import Path

import torch

from experiment import initialize, load_data, predict, residual_jacobian

HERE = Path(__file__).resolve().parent
output = {}
for name in ["r02", "r04", "r05", "r08"]:
    config = json.loads((HERE / f"{name}.json").read_text())
    theta = initialize(config)
    x, y = load_data(config)
    jac = residual_jacobian(theta, x)
    residual = predict(theta, x) - y
    gram = jac.T @ jac / len(x)
    component = jac.T * (residual / (residual.square() + 2 * config["shift"]).sqrt())
    pullback = component @ component.T / len(x)
    singular = torch.linalg.svdvals(jac)
    output[name] = {
        "jacobian_singular_values": singular.tolist(),
        "jacobian_rank_default": torch.linalg.matrix_rank(jac).item(),
        "jacobian_rank_relative_1e-10": int((singular > 1e-10 * singular[0]).sum()),
        "relative_matrix_error": ((gram - pullback).norm() / gram.norm()).item(),
    }
(HERE / "geometry.json").write_text(json.dumps(output, indent=2))
for name, result in output.items():
    print(name, {k: v for k, v in result.items() if "values" not in k})
