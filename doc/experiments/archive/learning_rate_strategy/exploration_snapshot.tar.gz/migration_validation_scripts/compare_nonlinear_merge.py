"""Compare completed formal runs against immutable Challenge histories."""
import csv
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tracking import read_config

reference = ROOT / "Challenge/fig3_reproduction"
sources = {}
for relative in ("runs/c1_sav_esav/comparison.json", "runs/d1_pb_no_relax/comparison.json"):
    sources.update(json.loads((reference / relative).read_text())["curves"])
results = {}
for folder in sorted((ROOT / "TMP/nonlinear_merge_records").iterdir(), key=lambda p: p.stat().st_mtime):
    if not (folder / "config.json").exists() or not (folder / "summary.json").exists():
        continue
    raw = json.loads((folder / "config.json").read_text())
    if raw.get("experiment", {}).get("input_sha256") != (
            "163089e48357b9a8ee996fd63963dc883d1ebd931f1a3815f510f294615075fe"):
        continue
    config = read_config(raw)
    summary = json.loads((folder / "summary.json").read_text())
    if summary.get("status") != "completed":
        continue
    key = config["method"]
    if key.startswith("pb_"):
        key += f"_m{config['components']}"
    if config["relax"]:
        key = "relax_" + key
    if key not in sources:
        continue
    with (folder / "history.csv").open() as f:
        actual = list(csv.DictReader(f))
    with (reference / sources[key]["source"] / "history.csv").open() as f:
        expected = list(csv.DictReader(f))
    assert len(actual) == len(expected) == 601
    measurements = {}
    for field in ("objective", "lr", "backtracks"):
        if field not in expected[0]:
            continue
        a = np.array([float(row[field]) for row in actual])
        b = np.array([float(row[field]) for row in expected])
        measurements[field] = {
            "max_absolute_error": float(abs(a-b).max()),
            "within_tolerance": bool(np.allclose(a, b, atol=1e-10, rtol=1e-6)),
            "first_20_within_tolerance": bool(np.allclose(a[:21], b[:21], atol=1e-10, rtol=1e-6)),
        }
    results[key] = {"run_id": folder.name, "source": sources[key]["source"],
                    "url": "https://forge.coreweave.com/wandb/pheonizard-university-of-nottingham/"
                           f"NumericalScheme/runs/{folder.name}",
                    "reference_url": sources[key]["url"],
                    "formal_history": str((folder / "history.csv").relative_to(ROOT)),
                    "final_objective": float(actual[-1]["objective"]),
                    "reference_final_objective": float(expected[-1]["objective"]),
                    "checks": measurements}
output = {"atol": 1e-10, "rtol": 1e-6, "completed_configurations": len(results), "runs": results}
(ROOT / "TMP/nonlinear_merge_trajectories.json").write_text(json.dumps(output, indent=2))
for key, result in results.items():
    print(key, result["run_id"], result["final_objective"], result["checks"])
print("completed", len(results), "/ 12")
