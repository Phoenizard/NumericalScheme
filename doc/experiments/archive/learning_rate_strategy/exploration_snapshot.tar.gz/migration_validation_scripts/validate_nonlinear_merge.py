"""Validate migrated inputs, geometry, native steps and shared-loop integration."""
import hashlib
import json
import subprocess
import sys
from functools import partial
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "Challenge/fig3_reproduction"))
import torch
import accepted_experiment as reference
from c1_experiment import controlled_rate, accepted_step, nested_groups
from learning_rate import curvature_rate
from network.nonlinear_regression import TanhRegressor
from problem import nonlinear_regression as problem
from problem.config import PROBLEMS
from optimizer import sav, pb_sav, esav, pb_esav
from train import _armijo_step
import run
import tracking
from plot_figure import step_label

config = json.loads((reference.HERE / "c1_config.json").read_text())
settings = PROBLEMS["nonlinear_regression"]
path = ROOT / settings["data_path"]
if not path.exists():
    problem.generate_data()
data = torch.load(path, weights_only=True)
x, y = data["x_train"], data["y_train"]
rx, ry = reference.load_data(config)
assert torch.equal(x.flatten(), rx) and torch.equal(y.flatten(), ry)
model = TanhRegressor(settings)
flat = torch.cat([p.detach().flatten() for p in model.parameters()])
assert torch.equal(flat, reference.initialize(config))
digest = hashlib.sha256(torch.cat((x.flatten(), y.flatten(), flat)).numpy().tobytes()).hexdigest()
assert digest == config["expected_input_sha256"]
checks = 0
rejections = 0
for method in ("sav", "esav", "pb_sav", "pb_esav"):
    for count in ([8, 16, 30] if method.startswith("pb_") else [1]):
        groups = problem.make_groups(30, count, 42, "numpy")
        assert all(torch.equal(a, b) for a, b in zip(groups, nested_groups(30, count, 42)))
        for relaxed in (False, True):
            model = TanhRegressor(settings)
            parameters = tuple(model.parameters())
            loss = partial(problem.split_energy_loss, model, x, y, groups)
            module = {"sav": sav, "pb_sav": pb_sav, "esav": esav, "pb_esav": pb_esav}[method]
            energy = sum(loss()).detach()
            state = module.initialize(loss()) if "esav" in method else None
            if state is not None:
                state["log_r"] -= 0.03
                if method == "pb_esav":
                    state["log_r_i"] += torch.linspace(-0.03, 0.03, count)
            jac, columns = problem.controller_geometry(model, x, y, groups, method, 1e-10, state)
            torch.testing.assert_close(jac, reference.residual_jacobian(flat, rx), atol=0, rtol=0)
            for previous in (0.0, 0.3, 30.0):
                eta = curvature_rate(previous, (jac, columns), settings["controller"])
                expected = controlled_rate(1.0 if previous == 0 else 1.1 * previous,
                                           jac, rx, columns, config)
                assert eta == expected
            grad = jac.T @ (reference.predict(flat, rx) - ry) / len(rx)
            ratio = ((state["log_r"] - energy / (4 * state["initial_energy"])).exp()
                     if state is not None else torch.tensor(0.97))
            q = (energy + 1e-10).sqrt() * ratio
            original_state = {k: v.clone() for k, v in state.items()} if state else None
            trial, trial_energy, delta, eta, backtracks = accepted_step(
                flat, rx, ry, energy, grad, columns, -ratio * grad, 100.0, config,
            )
            def update(lr):
                if state is not None:
                    return module.step(parameters, loss, state, lr, relax=relaxed)
                return module.step(parameters, loss, q, lr, 1e-10, relaxed)
            aux, actual_eta, actual_backtracks = _armijo_step(
                parameters, loss, update, 100.0, settings["line_search"], 1,
            )
            torch.testing.assert_close(torch.cat([p.detach().flatten() for p in parameters]),
                                       trial, atol=1e-11, rtol=1e-9)
            assert actual_eta == eta and actual_backtracks == backtracks
            if state:
                for key in state:
                    assert torch.equal(state[key], original_state[key])
                expected_aux = (torch.minimum(trial_energy / (4 * state["initial_energy"]),
                                              state["log_r"]) if relaxed else
                                state["log_r"] + ratio * (grad @ delta) / (4 * state["initial_energy"]))
                torch.testing.assert_close(aux["log_r"], expected_aux, atol=1e-11, rtol=1e-9)
            else:
                expected_aux = (torch.minimum(trial_energy + 1e-10, q.square()).sqrt()
                                if relaxed else q + grad @ delta / (2 * (energy + 1e-10).sqrt()))
                torch.testing.assert_close(aux, expected_aux, atol=1e-11, rtol=1e-9)
            checks += 1
            rejections += actual_backtracks

# Assembly checks perform one validated step only, without a training experiment.
class Recorder:
    io_seconds = 0
    run = type("Run", (), {"url": "local one-step validation"})()
    def __init__(self, resolved, name):
        self.config = tracking.build_config(resolved)
        decoded = tracking.read_config(self.config)
        assert decoded["step_policy"] == resolved["step_policy"]
        assert step_label(decoded)
        if resolved["method"] in ("sav", "pb_sav", "esav", "pb_esav"):
            assert self.config["control"]["controller"] == settings["controller"]
        assert resolved["input_sha256"] == digest
    def record(self, row):
        pass
    def finish(self, *args, **kwargs):
        pass

real_train = run.train
def one_step(*args, **kwargs):
    kwargs["steps"] = 1
    return real_train(*args, **kwargs)
run.train = one_step
run.WandbRecorder = Recorder
for method, count, relaxed in [
        ("sav", 1, False), ("sav", 1, True), ("esav", 1, False), ("esav", 1, True),
        ("gd", 1, False), ("adam", 1, False),
        *[(method, count, False) for method in ("pb_sav", "pb_esav") for count in (8, 16, 30)]]:
    history = run.run_experiment("nonlinear_regression", method, m=count, relax=relaxed)
    assert len(history) == 2

old = {}
exec(subprocess.check_output(["git", "show", "HEAD:problem/config.py"], cwd=ROOT), old)
assert PROBLEMS["quadratic"] == old["PROBLEMS"]["quadratic"]
assert PROBLEMS["darcy_deeponet"] == old["PROBLEMS"]["darcy_deeponet"]
legacy = {**settings, **settings["legacy_momentum"]}
for key, value in old["PROBLEMS"]["nonlinear_regression"].items():
    assert legacy[key] == value, key
result = {"status": "passed", "input_sha256": digest, "native_step_cases": checks,
          "rejected_trials_checked": rejections, "assembly_cases": 12,
          "quadratic_darcy_momentum_unchanged": True}
(ROOT / "TMP/nonlinear_merge_validation.json").write_text(json.dumps(result, indent=2))
print(json.dumps(result))
