"""Persist the checked migration summary and verify document resource links."""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
report = json.loads((ROOT / "TMP/nonlinear_merge_trajectories.json").read_text())
assert report["completed_configurations"] == 12
for result in report["runs"].values():
    assert all(check["within_tolerance"] for check in result["checks"].values())
report["single_step_validation"] = json.loads((ROOT / "TMP/nonlinear_merge_validation.json").read_text())
report["edge_validation"] = json.loads((ROOT / "TMP/nonlinear_merge_edges.json").read_text())
report["status"] = "passed"
destination = ROOT / "doc/experiments/learning_rate_strategy_validation.json"
destination.write_text(json.dumps(report, indent=2) + "\n")
document = ROOT / "doc/experiments/learning_rate_strategy_optimization.md"
for link in re.findall(r"\]\(([^)]+)\)", document.read_text()):
    if not link.startswith("https:"):
        assert (document.parent / link).exists(), link
figures = {
    "figure3_reference.png": "figure3_reference.png",
    "accepted_figure3.png": "accepted_figure3.png",
    "sav_esav_relax_adam.png": "runs/c1_sav_esav/sav_esav_relax_adam.png",
    "sav_esav_pb_8_16_30.png": "runs/d1_pb_no_relax/sav_esav_pb_8_16_30.png",
}
for target, source in figures.items():
    assert (document.parent / "figures/learning_rate_strategy" / target).read_bytes() == (
        ROOT / "Challenge/fig3_reproduction" / source).read_bytes()
print("12 configurations passed; all document links and four unchanged figures verified")
print("max objective error:", max(r["checks"]["objective"]["max_absolute_error"]
                                  for r in report["runs"].values()))
print("max SAV/ESAV objective error:", max(r["checks"]["objective"]["max_absolute_error"]
                                  for key, r in report["runs"].items() if key not in ("adam", "gd")))
